# AWS CloudFormation Scripts & Templates

First run networking stack
#Creating a Stack using Amazon CloudFormation
Open terminal and run shell script using ./csye6225-aws-cf-create-stack.sh <STACK NAME>

#Deleting a Stack using Amazon CloudFormation
Open terminal and run shell script using ./csye6225-aws-cf-terminate-stack.sh <STACK NAME>


Then create Application Stack
#Creating a Stack using Amazon CloudFormation
Open terminal and run shell script using ./csye6225-aws-cf-create-application-stack.sh <STACK NAME1>

#Deleting a Stack using Amazon CloudFormation
Open terminal and run shell script using ./csye6225-aws-cf-terminate-application-stack.sh <STACK NAME1>


